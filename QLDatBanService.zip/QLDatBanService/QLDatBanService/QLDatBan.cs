﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace QLDatBanService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "QLDatBan" in both code and config file together.
    public class QLDatBan : IQLDatBan
    {
        public DataSet CTDatBan()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QLDatBan"].ConnectionString);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from ChiTietDatBan", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public int SelectBan(DatBan p)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QLDatBan"].ConnectionString);
            SqlCommand com = conn.CreateCommand();
            try
            {
                com.CommandText = "Select * from DatBan where SHDatBan=@SHDatBan";
                com.Parameters.AddWithValue("SHDatBan", p.SHDatBan);
                com.CommandType = CommandType.Text;
                conn.Open();
                return com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if(conn!=null)
                {
                    conn.Close();
                }
            }
        }

        DataSet IQLDatBan.QLDatBan()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QLDatBan"].ConnectionString);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter("select * from DatBan", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
    }
}
