﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;

namespace QLDatBanService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IQLDatBan" in both code and config file together.
    [ServiceContract]
    public interface IQLDatBan
    {
        [OperationContract]
        DataSet QLDatBan();

        [OperationContract]
        DataSet CTDatBan();

        [OperationContract]
        int SelectBan(DatBan p);
    }
}
