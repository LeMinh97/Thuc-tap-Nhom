﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace QLDatBanService
{
    [DataContract]
    public class DatBan
    {
        [DataMember]
        public int SHDatBan { get; set; }

        [DataMember]
        public int MaKH { get; set; }

        [DataMember]
        public int MaBan { get; set; }

        [DataMember]
        public int NgayHen { get; set; }

        [DataMember]
        public int TinhTrangPhucVu { get; set; }

        [DataMember]
        public int TinhTrangThanhToan { get; set; }
    }
}
