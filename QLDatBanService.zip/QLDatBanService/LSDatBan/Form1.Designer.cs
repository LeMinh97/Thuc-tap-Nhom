﻿namespace LSDatBan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDatBan = new System.Windows.Forms.DataGridView();
            this.LSDatBan = new System.Windows.Forms.Button();
            this.CTDatBan = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatBan)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDatBan
            // 
            this.dgvDatBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatBan.Location = new System.Drawing.Point(0, 170);
            this.dgvDatBan.Name = "dgvDatBan";
            this.dgvDatBan.Size = new System.Drawing.Size(799, 278);
            this.dgvDatBan.TabIndex = 0;
            // 
            // LSDatBan
            // 
            this.LSDatBan.Location = new System.Drawing.Point(47, 46);
            this.LSDatBan.Name = "LSDatBan";
            this.LSDatBan.Size = new System.Drawing.Size(139, 23);
            this.LSDatBan.TabIndex = 1;
            this.LSDatBan.Text = "Xem LS Dat Ban";
            this.LSDatBan.UseVisualStyleBackColor = true;
            this.LSDatBan.Click += new System.EventHandler(this.LSDatBan_Click);
            // 
            // CTDatBan
            // 
            this.CTDatBan.Location = new System.Drawing.Point(495, 46);
            this.CTDatBan.Name = "CTDatBan";
            this.CTDatBan.Size = new System.Drawing.Size(159, 23);
            this.CTDatBan.TabIndex = 2;
            this.CTDatBan.Text = "Xem Chi tiet dat Ban";
            this.CTDatBan.UseVisualStyleBackColor = true;
            this.CTDatBan.Click += new System.EventHandler(this.CTDatBan_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 406);
            this.Controls.Add(this.CTDatBan);
            this.Controls.Add(this.LSDatBan);
            this.Controls.Add(this.dgvDatBan);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatBan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDatBan;
        private System.Windows.Forms.Button LSDatBan;
        private System.Windows.Forms.Button CTDatBan;
    }
}

