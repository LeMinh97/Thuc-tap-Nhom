﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LSDatBan
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=STCHIEN\SQLEXPRESS;Initial Catalog=QLDatBan;Integrated Security=True");
            try
            {
                conn.Open();
                string usr = txtUser.Text;
                string pass = txtPass.Text;
                string sql= "select * from QuanLi where TenDN='" +usr+ "' and  MatKhau= '" +pass+ "'" ;
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dta = cmd.ExecuteReader();
                if(dta.Read()==true)
                {
                    MessageBox.Show("Đăng Nhập Thành Công");
                    this.Hide();
                    Form1 f = new Form1();
                    f.Show();
                }
                else
                {
                    MessageBox.Show("Đăng Nhập Thất Bại");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult di = MessageBox.Show("Bạn có muốn thoát không ?", "Cảnh báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if(di==DialogResult.OK)
            {
                Application.Exit();
            }
            
        }
    }
}
