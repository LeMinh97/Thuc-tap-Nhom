﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LSDatBan.QLDatServiceReference;

namespace LSDatBan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LSDatBan_Click(object sender, EventArgs e)
        {
            QLDatBanClient service = new QLDatBanClient();
            DataSet dsDat = service.QLDatBan();
            dgvDatBan.DataSource = dsDat.Tables[0];
        }

        private void CTDatBan_Click(object sender, EventArgs e)
        {
            QLDatBanClient service = new QLDatBanClient();
            DataSet ds = service.CTDatBan();
            dgvDatBan.DataSource = ds.Tables[0];
        }
    }
}
